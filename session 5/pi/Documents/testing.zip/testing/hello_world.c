#include <stdio.h>
#include <stdlib.h>

    /* HELLO WORLD
first c code - 14/10/19 */

void main(){
    printf("Hello world! \n");
}
